package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentPortal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentPortal frame = new StudentPortal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentPortal() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowAssingment ob6=new ShowAssingment();
				ob6.setVisible(true);
			}
			
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\assign.jpg"));
		btnNewButton.setBounds(29, 102, 243, 191);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowStuRec ob=new ShowStuRec();
				ob.setVisible(true);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\Result.jpg"));
		btnNewButton_1.setBounds(514, 102, 259, 191);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("New button");
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\attt.jpg"));
		btnNewButton_2.setBounds(972, 109, 222, 177);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("New button");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Showholiday obj=new Showholiday();
				obj.setVisible(true);
			}
		});
		btnNewButton_3.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\holiday.png"));
		btnNewButton_3.setBounds(41, 316, 190, 162);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("BACK");
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBounds(31, 548, 89, 43);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("New button");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowTimetable obj4=new ShowTimetable();
				obj4.setVisible(true);
			}
		});
		btnNewButton_5.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\timetable.png"));
		btnNewButton_5.setBounds(514, 316, 290, 162);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("New button");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowExam obj5=new ShowExam();
				obj5.setVisible(true);
			}
		});
		btnNewButton_6.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\exam.png"));
		btnNewButton_6.setBounds(972, 316, 259, 162);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("EXIT");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);	
				StudentPortal obj=new StudentPortal();
				obj.setVisible(false);
				}
		});
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_7.setBounds(1222, 551, 89, 37);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("LOGOUT");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Frame1 ob =new Frame1();
				ob.setVisible(true);
			}
		});
		btnNewButton_8.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_8.setBounds(1218, 11, 111, 23);
		contentPane.add(btnNewButton_8);
		
		JLabel lblNewLabel = new JLabel("                        STUDENT PORTAL");
		lblNewLabel.setBackground(new Color(255, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(414, 17, 378, 37);
		contentPane.add(lblNewLabel);
	}

}
