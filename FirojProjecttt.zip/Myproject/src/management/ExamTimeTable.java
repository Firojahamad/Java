package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExamTimeTable extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExamTimeTable frame = new ExamTimeTable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExamTimeTable() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("EXAM TIME TABLE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(589, 11, 161, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("  DATE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(449, 97, 147, 26);
		contentPane.add(lblNewLabel_1);
		
		t1 = new JTextField();
		t1.setBounds(553, 97, 237, 25);
		contentPane.add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("SUBJECT");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(449, 157, 147, 26);
		contentPane.add(lblNewLabel_1_1);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(553, 162, 237, 25);
		contentPane.add(t2);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("TIME");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_1.setBounds(449, 230, 147, 26);
		contentPane.add(lblNewLabel_1_1_1);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(553, 235, 237, 25);
		contentPane.add(t3);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String d=t1.getText();
				String sub=t2.getText();
				String time=t3.getText();
				String room=t4.getText();
				if(e.getSource()==btnNewButton)
				{
					try {
						Conn cc=new Conn();
						String q="insert into examtime values('"+d+"','"+sub+"','"+time+"','"+room+"')";
						cc.s.executeUpdate(q);
						JOptionPane.showMessageDialog(null,"Data inserted");
						ExamTimeTable ob=new ExamTimeTable();
						ob.setVisible(false);
					}
					catch(Exception e4)
					{
						System.out.println("The Error is :"+e4);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(473, 372, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CANCEL");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(705, 372, 111, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setBounds(320, 461, 89, 23);
		contentPane.add(btnBack);
		
		JButton btnNewButton_2 = new JButton("EXIT");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(857, 444, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_2 = new JLabel("ROOM.NO");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(437, 294, 89, 14);
		contentPane.add(lblNewLabel_2);
		
		t4 = new JTextField();
		t4.setColumns(10);
		t4.setBounds(553, 291, 237, 25);
		contentPane.add(t4);
	}

}
