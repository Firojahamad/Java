package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Frame1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame1 frame = new Frame1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frame1() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\university.jpg"));
		lblNewLabel.setBounds(352, 194, 1008, 555);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 255, 255));
		panel.setBounds(0, 0, 1360, 209);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(657, 12, 0, 0);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\university log.jpg"));
		lblNewLabel_2.setBounds(1144, 0, 216, 209);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("     LOVELY PROFESSIONAL UNIVERSITY");
		lblNewLabel_3.setFont(new Font("Verdana", Font.PLAIN, 54));
		lblNewLabel_3.setBounds(0, 12, 1134, 59);
		panel.add(lblNewLabel_3);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 255, 255));
		panel_1.setBounds(0, 209, 353, 518);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\LOGIN2.jpg"));
		lblNewLabel_4.setBounds(52, 11, 252, 68);
		panel_1.add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton(" ADMIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Frame2 obj2=new Frame2();
				obj2.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 40));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(244, 11, 81));
		btnNewButton.setBounds(52, 109, 252, 62);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton(" FACULTY");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Faculty obj3=new Faculty();
				obj3.setVisible(true);
			}
		});
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setBackground(new Color(247, 2, 64));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 40));
		btnNewButton_1.setBounds(56, 203, 248, 62);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("STUDENT");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Studentlogin obj4=new Studentlogin();
				obj4.setVisible(true);
			}
		});
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setBackground(new Color(239, 12, 91));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 40));
		btnNewButton_2.setBounds(56, 299, 248, 57);
		panel_1.add(btnNewButton_2);
	}
}
