package management;

import java.awt.EventQueue;
import javax.swing.*;
import java.sql.*; 

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;

public class Testting extends JFrame {
	public byte[]photo;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Testting frame = new Testting();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Testting() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(10, 11, 183, 182);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser choose = new JFileChooser();
		        choose.showOpenDialog(null);
		        File f = choose.getSelectedFile();
		        lblNewLabel.setIcon(new ImageIcon(f.toString()));
		        String filename = f.getAbsolutePath();
		        try (FileInputStream fis = new FileInputStream(filename);
		             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
		            byte[] buf = new byte[1024];
		            for (int i; (i = fis.read(buf)) != -1;) {
		                bos.write(buf, 0, i);
		            }
		            photo = bos.toByteArray();
		            Conn con = new Conn();
		            String q = "insert into imge values (?,?)";
		            try (PreparedStatement ps = con.c.prepareStatement(q)) {
		                ps.setInt(1, 78);
		                ps.setBytes(2, photo);
		                ps.executeUpdate();
		            }
		        } catch (IOException | SQLException e5) {
		            e5.printStackTrace();
		        }
				
			}});
		btnNewButton.setBounds(203, 11, 89, 23);
		contentPane.add(btnNewButton);
		JLabel lab2 = new JLabel("");
		lab2.setBounds(213, 79, 211, 171);
		contentPane.add(lab2);
		
		JButton btnNewButton_1 = new JButton("Show");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String d="SELECT im FROM imge where id=4";
				try {
					//byte[]ll=null;
					//InputStream inp;
					Conn cc=new Conn();
					//PreparedStatement ps = cc.c.prepareStatement(d);
					ResultSet r=cc.s.executeQuery(d);
					//ps.setInt(1,"im");
					if(r.next())
					{
						byte[]b=r.getBytes("im");
					
					lab2.setIcon(new ImageIcon(b));
					}
				}
				catch(Exception kl){
					
				}
				
			}
		});
		btnNewButton_1.setBounds(203, 45, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(302, 11, 122, 20);
		contentPane.add(dateChooser);
		
//		JLabel lab2 = new JLabel("2");
//		lab2.setBounds(213, 79, 211, 171);
//		contentPane.add(lab2);
	}
}
