package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ShowAssingment extends JFrame {

	private JPanel contentPane;
	private JTable table6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowAssingment frame = new ShowAssingment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowAssingment() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("SHOW");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Conn cc=new Conn();
					String q="select * from assingment";
					//ResultSet rs = cc.s.executeQuery(q); 
					cc.r=cc.s.executeQuery(q);
					cc.rm=cc.r.getMetaData();
					DefaultTableModel model=(DefaultTableModel) table6.getModel();
					int cols=cc.rm.getColumnCount();
					String[] colName=new String[cols];
					String  que,sub;
					for(int i=0;i<cols;i++)
						colName[i]=cc.rm.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					while(cc.r.next()) {
						sub=cc.r.getString(1);
						que=cc.r.getString(2);
				
						String[]row= {sub,que};
						model.addRow(row);
					}
					
				}
				catch(Exception e4)
				{
					System.out.println("The Error is :"+e4);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(640, 10, 89, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(367, 31, 651, 325);
		contentPane.add(scrollPane);
		
		table6 = new JTable();
		scrollPane.setViewportView(table6);
	}

}
