package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

public class TeacherReg extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField tfh;
	public byte[]photto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeacherReg frame = new TeacherReg();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TeacherReg() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel btykdk = new JLabel("              TeacherRegistration");
		btykdk.setBounds(565, 10, 232, 31);
		btykdk.setFont(new Font("Tahoma", Font.BOLD, 15));
		contentPane.add(btykdk);
		
		JLabel lblNewLabel = new JLabel("Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(565, 79, 50, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblName.setBounds(565, 121, 50, 31);
		contentPane.add(lblName);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAge.setBounds(565, 163, 50, 31);
		contentPane.add(lblAge);
		
		JLabel lblSubject = new JLabel("Gender");
		lblSubject.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSubject.setBounds(541, 211, 74, 31);
		contentPane.add(lblSubject);
		
		JLabel lblSubject_1 = new JLabel("Subject");
		lblSubject_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSubject_1.setBounds(551, 253, 64, 31);
		contentPane.add(lblSubject_1);
		
		t1 = new JTextField();
		t1.setBounds(619, 79, 178, 27);
		contentPane.add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(619, 121, 178, 27);
		contentPane.add(t2);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(619, 170, 178, 27);
		contentPane.add(t3);
		
		JRadioButton rd1 = new JRadioButton("Male");
		rd1.setFont(new Font("Tahoma", Font.BOLD, 14));
		rd1.setBounds(617, 217, 74, 23);
		contentPane.add(rd1);
		
		JRadioButton rd2 = new JRadioButton("Female");
		rd2.setFont(new Font("Tahoma", Font.BOLD, 15));
		rd2.setBounds(712, 215, 90, 23);
		contentPane.add(rd2);
		ButtonGroup group = new ButtonGroup();
		group.add(rd1);
		group.add(rd2);
		JComboBox com1 = new JComboBox();
		com1.setBounds(625, 259, 172, 22);
		contentPane.add(com1);
		com1.addItem("Select");
		com1.addItem("JAVA");
		com1.addItem("C++");
		com1.addItem("Web Technology");
		com1.addItem("Discreate Mathmetics");
		com1.addItem("Ethics");
		JLabel LLB = new JLabel("");
		LLB.setBounds(897, 53, 184, 189);
		contentPane.add(LLB);
		JButton btnNewButton_1 = new JButton("Upload(img)");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser choose = new JFileChooser();
		        choose.showOpenDialog(null);
		        File f = choose.getSelectedFile();
		        LLB.setIcon(new ImageIcon(f.toString()));
		        String filename = f.getAbsolutePath();
		        tfh.setText(filename);
		        try (FileInputStream fis = new FileInputStream(filename);
		             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
		            byte[] buf = new byte[1024];
		            for (int i; (i = fis.read(buf)) != -1;) {
		                bos.write(buf, 0, i);
		            }
		            photto = bos.toByteArray();
		        } catch (Exception e5) {
		            e5.printStackTrace();
		        }
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(489, 295, 125, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String gen=null;
				if(rd1.isSelected())
				{
					gen="Male";
				}
				else {
					gen="Female";
				}
				String Rol=t1.getText();
				String nam2=t2.getText();
				String age=t3.getText();
				String sub=com1.getSelectedItem().toString();
			if(e.getSource()==btnNewButton)	
			{
//				try {
//					Conn cc=new Conn();
//					String q="insert into techreg values('"+Rol+"','"+nam2+"','"+age+"','"+gen+"','"+sub+"')";
//					cc.s.executeUpdate(q);
//					JOptionPane.showMessageDialog(null,"Data inserted");
//					Holiday ob=new Holiday();
//					ob.setVisible(false);
//				}
//				catch(Exception e4)
//				{
//					System.out.println("The Error is :"+e4);
//				}
				try {
					Conn cc=new Conn();
					Conn con = new Conn();
		            String q = "insert into techreg(ID,Name,Age,Gender,Subject,Img) values (?,?,?,?,?,?)";
		            try (PreparedStatement ps = con.c.prepareStatement(q)) {
		                ps.setString(1, Rol);
		                ps.setString(2, nam2);
		                ps.setString(3, age);
		                ps.setString(4, gen);
		                ps.setString(5,sub);
		                ps.setBytes(6, photto);
		                ps.executeUpdate();
		            }
					JOptionPane.showMessageDialog(null,"Data inserted");
					Holiday ob=new Holiday();
					ob.setVisible(false);
				}
				catch(Exception e4)
				{
					System.out.println("The Error is :"+e4);
				}
			}
			}
		});
		btnNewButton.setBounds(622, 332, 112, 23);
		contentPane.add(btnNewButton);
		
//		JLabel LLB = new JLabel("New label");
//		LLB.setBounds(897, 53, 184, 189);
//		contentPane.add(LLB);
		
//		JButton btnNewButton_1 = new JButton("Upload(img)");
//		btnNewButton_1.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				JFileChooser choose = new JFileChooser();
//		        choose.showOpenDialog(null);
//		        File f = choose.getSelectedFile();
//		        LLB.setIcon(new ImageIcon(f.toString()));
//		        String filename = f.getAbsolutePath();
//		        tfh.setText(filename);
//		        try (FileInputStream fis = new FileInputStream(filename);
//		             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
//		            byte[] buf = new byte[1024];
//		            for (int i; (i = fis.read(buf)) != -1;) {
//		                bos.write(buf, 0, i);
//		            }
//		            photto = bos.toByteArray();
//		        } catch (Exception e5) {
//		            e5.printStackTrace();
//		        }
//			}
//		});
//		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
//		btnNewButton_1.setBounds(489, 295, 125, 23);
//		contentPane.add(btnNewButton_1);
		
		tfh = new JTextField();
		tfh.setBounds(613, 295, 184, 22);
		contentPane.add(tfh);
		tfh.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Refresh");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LLB.setVisible(false);
				com1.setSelectedIndex(0);
				tfh.setText("");
				t1.setText(" ");
				t2.setText("");
				t3.setText("");
				//dateChooser.setDate(null);
				rd1.setSelected(false);
				rd2.setSelected(false);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.setBounds(760, 334, 89, 23);
		contentPane.add(btnNewButton_2);
	}
}
