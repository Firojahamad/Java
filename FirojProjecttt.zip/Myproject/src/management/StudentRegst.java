package management;

import java.awt.EventQueue;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.sql.*;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.io.*;

public class StudentRegst extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t2;
	private JTextField tff1;
	private byte[]photto=null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentRegst frame = new StudentRegst();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentRegst() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Student Registration");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(605, 10, 192, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Roll.No.");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(453, 80, 100, 22);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Name");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(453, 123, 100, 22);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Age");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(453, 167, 100, 22);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Gender");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_3.setBounds(453, 208, 100, 22);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Subject");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_4.setBounds(453, 250, 100, 22);
		contentPane.add(lblNewLabel_1_4);
		JComboBox com1 = new JComboBox();
		com1.setBounds(549, 252, 168, 22);
		contentPane.add(com1);
		com1.addItem("Select");
		com1.addItem("JAVA");
		com1.addItem("C++");
		com1.addItem("Web Technology");
		com1.addItem("Discreate Mathmetics");
		com1.addItem("Ethics");
		
		t1 = new JTextField();
		t1.setBounds(549, 83, 168, 20);
		contentPane.add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(549, 126, 168, 20);
		contentPane.add(t2);
		
		JRadioButton rd1 = new JRadioButton("Male");
		rd1.setFont(new Font("Tahoma", Font.BOLD, 13));
		rd1.setBounds(540, 210, 73, 23);
		contentPane.add(rd1);
		
		JRadioButton rd2 = new JRadioButton("Female");
		rd2.setFont(new Font("Tahoma", Font.BOLD, 13));
		rd2.setBounds(608, 210, 109, 23);
		contentPane.add(rd2);
		ButtonGroup group = new ButtonGroup();
		group.add(rd1);
		group.add(rd2);
		JLabel lab1 = new JLabel("");
		lab1.setBounds(825, 63, 221, 209);
		contentPane.add(lab1);
		
		tff1 = new JTextField();
		tff1.setBounds(549, 302, 168, 20);
		contentPane.add(tff1);
		tff1.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Upload(image)");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser choose = new JFileChooser();
		        choose.showOpenDialog(null);
		        File f = choose.getSelectedFile();
		        lab1.setIcon(new ImageIcon(f.toString()));
		        String filename = f.getAbsolutePath();
		        tff1.setText(filename);
		        try (FileInputStream fis = new FileInputStream(filename);
		             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
		            byte[] buf = new byte[1024];
		            for (int i; (i = fis.read(buf)) != -1;) {
		                bos.write(buf, 0, i);
		            }
		            photto = bos.toByteArray();
		        } catch (Exception e5) {
		            e5.printStackTrace();
		        }
			}

		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(409, 301, 130, 23);
		contentPane.add(btnNewButton_1);
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(551, 169, 166, 20);
		contentPane.add(dateChooser);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String gen=null;
				if(rd1.isSelected())
				{
					gen="Male";
				}
				else {
					gen="Female";
				}
				int Rol=Integer.parseInt(t1.getText());
				String nam2=t2.getText();
				Date age=dateChooser.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		        String dateString = sdf.format(age);
				String sub=com1.getSelectedItem().toString();
			if(e.getSource()==btnNewButton)	
			{
				try {
					Conn cc=new Conn();
					Conn con = new Conn();
		            String q = "insert into studentreg values (?,?,?,?,?,?)";
		            try (PreparedStatement ps = con.c.prepareStatement(q)) {
		                ps.setInt(1, Rol);
		                ps.setString(2, nam2);
		                ps.setString(3, dateString);
		                ps.setString(4, gen);
		                ps.setString(5,sub);
		                ps.setBytes(6, photto);
		                ps.executeUpdate();
		            }
					JOptionPane.showMessageDialog(null,"Data inserted");
					Holiday ob=new Holiday();
					ob.setVisible(false);
				}
				catch(Exception e4)
				{
					System.out.println("The Error is :"+e4);
				}
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(513, 335, 124, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Refresh");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lab1.setVisible(false);
				com1.setSelectedIndex(0);
				tff1.setText("");
				t1.setText(" ");
				t2.setText("");
				dateChooser.setDate(null);
				rd1.setSelected(false);
				rd2.setSelected(false);
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.setBounds(676, 333, 89, 23);
		contentPane.add(btnNewButton_2);	
	}
}
