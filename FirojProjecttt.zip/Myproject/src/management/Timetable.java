package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Timetable extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Timetable frame = new Timetable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Timetable() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TIME TABLE");
		lblNewLabel.setBackground(new Color(128, 255, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(638, 0, 99, 31);
		contentPane.add(lblNewLabel);
		
		table = new JTable();
		table.setBounds(536, 249, 360, -152);
		contentPane.add(table);
		
		JLabel lblNewLabel_1 = new JLabel("  DATE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(462, 66, 65, 31);
		contentPane.add(lblNewLabel_1);
		
		t1 = new JTextField();
		t1.setBounds(586, 62, 207, 31);
		contentPane.add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("SUBJECT");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(447, 127, 80, 23);
		contentPane.add(lblNewLabel_2);
		
		t2 = new JTextField();
		t2.setBounds(586, 127, 207, 31);
		contentPane.add(t2);
		t2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("  TIME");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(447, 204, 70, 23);
		contentPane.add(lblNewLabel_3);
		
		t3 = new JTextField();
		t3.setBounds(585, 193, 208, 31);
		contentPane.add(t3);
		t3.setColumns(10);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String d=t1.getText();
				String sub=t2.getText();
				String tim=t3.getText();
				if(e.getSource()==btnNewButton)
				{
					try {
						Conn cc=new Conn();
						String q="insert into timetable values('"+d+"','"+sub+"','"+tim+"')";
						cc.s.executeUpdate(q);
						JOptionPane.showMessageDialog(null,"Data inserted");
						Timetable ob=new Timetable();
						ob.setVisible(false);
					}
					catch(Exception e4)
					{
						System.out.println("The Error is :"+e4);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(462, 298, 122, 42);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CANCEL");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(728, 298, 107, 42);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("BACK");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(371, 458, 99, 31);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("EXIT");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBounds(852, 451, 89, 31);
		contentPane.add(btnNewButton_3);
	}
}
