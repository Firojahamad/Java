package management;
import java.awt.*;
import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.JSlider;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.BevelBorder;

public class Showholiday extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Showholiday frame = new Showholiday();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Showholiday() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(64, 0, 64), new Color(0, 255, 0), new Color(0, 255, 255), new Color(255, 0, 128)));
		table.setBackground(new Color(128, 255, 255));
		table.setFont(new Font("Tahoma", Font.BOLD, 19));
		table.setBounds(662, 17, 0, 0);
		contentPane.add(table);
		
		JLabel lblNewLabel = new JLabel("Holiday List");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(600, 10, 102, 14);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(390, 66, 503, 336);
		contentPane.add(scrollPane);
		
		table1 = new JTable();
		scrollPane.setViewportView(table1);
		
		JButton btnNewButton = new JButton("SHOW");
		btnNewButton.addActionListener(new ActionListener() {


			public void actionPerformed(ActionEvent e) {
					try {
						Conn cc=new Conn();
						String q="select * from acadmicholiday";
						ResultSet rs = cc.s.executeQuery(q); 
						//cc.r=cc.s.executeQuery(q);
						cc.rm=rs.getMetaData();
						DefaultTableModel model=(DefaultTableModel) table1.getModel();
						int cols=cc.rm.getColumnCount();
						String[] colName=new String[cols];
						String  d,ev;
						for(int i=0;i<cols;i++)
							colName[i]=cc.rm.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						while(rs.next()) {
							d=rs.getString(1);
							ev=rs.getString(2);
							String[]row= {d,ev};
							model.addRow(row);
						}
						
					}
					catch(Exception e4)
					{
						System.out.println("The Error is :"+e4);
					}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(583, 32, 141, 23);
		contentPane.add(btnNewButton);
	}
}
