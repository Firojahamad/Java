package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class Faculty extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JPasswordField t2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Faculty frame = new Faculty();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Faculty() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\ACER\\Desktop\\learning\\faculty.jpg"));
		lblNewLabel.setBounds(597, 11, 223, 175);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 39));
		lblNewLabel_1.setBounds(476, 226, 109, 39);
		contentPane.add(lblNewLabel_1);
		
		t1 = new JTextField();
		t1.setFont(new Font("Tahoma", Font.BOLD, 15));
		t1.setBounds(597, 226, 223, 39);
		contentPane.add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 39));
		lblNewLabel_2.setBounds(409, 302, 176, 33);
		contentPane.add(lblNewLabel_2);
		
		t2 = new JPasswordField();
		t2.setFont(new Font("Tahoma", Font.BOLD, 15));
		t2.setBounds(597, 302, 223, 39);
		contentPane.add(t2);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try{
			            Conn c1 = new Conn();
			            String u = t1.getText();
			            String v = new String(t2.getPassword());
			            
			            String q = "select * from login where username='"+u+"' and password='"+v+"'";
			            ResultSet rs = c1.s.executeQuery(q); 
			            if(rs.next()){
			            	new FacultyPortal().setVisible(true);
			                setVisible(false);
			            }else{
			                JOptionPane.showMessageDialog(null, "Invalid login");
			                setVisible(false);
			            }
			        }catch(Exception e2){
			            e2.printStackTrace();;
			        }
			}
		});
		btnNewButton.setBackground(new Color(0, 255, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 39));
		btnNewButton.setBounds(511, 391, 156, 39);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CANCEL");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_1.setBackground(new Color(221, 95, 34));
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 39));
		btnNewButton_1.setBounds(721, 391, 187, 39);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("BACK");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Frame1 obj1=new Frame1();
				obj1.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 39));
		btnNewButton_2.setBounds(10, 647, 137, 39);
		contentPane.add(btnNewButton_2);
	}

}
