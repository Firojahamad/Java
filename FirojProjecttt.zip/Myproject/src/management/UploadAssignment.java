package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UploadAssignment extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UploadAssignment frame = new UploadAssignment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UploadAssignment() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UPLOAD ASSIGNMET");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(535, 11, 219, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SUBJECT");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(421, 81, 106, 14);
		contentPane.add(lblNewLabel_1);
		
		JComboBox com1 = new JComboBox();
		com1.setBounds(549, 79, 123, 22);
		contentPane.add(com1);
		com1.addItem("Select");
		com1.addItem("JAVA");
		com1.addItem("C++");
		com1.addItem("Web Technology");
		com1.addItem("Discreate Mathmetics");
		com1.addItem("Ethics");
		
		JLabel lblNewLabel_2 = new JLabel("Assignment");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(401, 168, 106, 23);
		contentPane.add(lblNewLabel_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(535, 169, 309, 182);
		contentPane.add(scrollPane);
		
		JTextArea textArea1 = new JTextArea();
		scrollPane.setViewportView(textArea1);
		
		JButton btnNewButton = new JButton("UPLOAD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sub=com1.getSelectedItem().toString();
				String Que=textArea1.getText();
			if(e.getSource()==btnNewButton)	
			{
				try {
					Conn cc=new Conn();
					String q="insert into assingment values('"+sub+"','"+Que+"')";
					cc.s.executeUpdate(q);
					JOptionPane.showMessageDialog(null,"Data inserted");
					Holiday ob=new Holiday();
					ob.setVisible(false);
				}
				catch(Exception e4)
				{
					System.out.println("The Error is :"+e4);
				}
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(1023, 321, 112, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("REFRESH");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea1.setText(" ");
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(868, 321, 106, 23);
		contentPane.add(btnNewButton_1);
		
	}
}
