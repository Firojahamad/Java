package management;

import java.awt.EventQueue;
import java.io.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.*;
public class ShowStuRec extends JFrame {

	private JPanel contentPane;
	private final JLabel lblNewLabel = new JLabel("Student Record");
	private JTextField tff;
	private JTable table3;
	private JScrollPane scrollPane;
	public static String m;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowStuRec frame = new ShowStuRec();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowStuRec() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewLabel.setBounds(434, 11, 131, 27);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		contentPane.add(lblNewLabel);
		
		JLabel llp = new JLabel("");
		llp.setBounds(923, 10, 198, 195);
		contentPane.add(llp);
		tff = new JTextField();
		tff.setBounds(483, 196, 86, 20);
		contentPane.add(tff);
		tff.setColumns(10);
		JButton btnNewButton = new JButton("SHOW");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 m=tff.getText();
				int k=Integer.parseInt(m);
				String d="SELECT img FROM studentreg WHERE Roll="+k;
				//String m=tff.getText();
				try {
					Conn cc=new Conn();
					ResultSet r=cc.s.executeQuery(d);
					if(r.next())
					{
						byte[]b=r.getBytes("img");
					
					llp.setIcon(new ImageIcon(b));
					}
				}
				catch(Exception kl){
					System.out.println(kl);
				}
				try {
					Conn cc=new Conn();
					
					//String q="SELECT Subject,Practical from umarks";
					//String ok="Select Name from studentreg";
					String q="SELECT studentreg.Roll,studentreg.Name,studentreg.Age,umarks.Subject,umarks.Practical,umarks.Theory,umarks.CA FROM studentreg JOIN umarks ON studentreg.Roll=umarks.Roll WHERE studentreg.Roll="+k;
					ResultSet rs = cc.s.executeQuery(q);
					
					//cc.r=cc.s.executeQuery(q);
					cc.rm=rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) table3.getModel();
					int cols=cc.rm.getColumnCount();
					String[] colName=new String[cols];
					String  nam,ag,gn,su;
					String rol,p,t,caa;
					for(int i=0;i<cols;i++)
						colName[i]=cc.rm.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					while(rs.next()) { 
						rol=Integer.toString(rs.getInt("Roll"));
						nam=rs.getString("Name");
						ag=rs.getString("Age");
						su=rs.getString("Subject");
						p=Integer.toString(rs.getInt("Practical"));
						t=Integer.toString(rs.getInt("Theory"));
						caa=Integer.toString(rs.getInt("CA"));
						//String[]row= {rol,nam,ag,su,p,t,caa};
						String[]row= {rol,nam,ag,su,p,t,caa};
						model.addRow(row);
					}
					
				}
				catch(Exception e4)
				{
					System.out.println("The Error is :"+e4);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(566, 194, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Roll.no");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(383, 198, 100, 14);
		contentPane.add(lblNewLabel_1);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(41, 216, 1111, 167);
		contentPane.add(scrollPane);
		
		table3 = new JTable();
		scrollPane.setViewportView(table3);
		
//		tff = new JTextField();
//		tff.setBounds(637, 42, 86, 20);
//		contentPane.add(tff);
//		tff.setColumns(10);
	}
}
