package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class ShowTech extends JFrame {

	private JPanel contentPane;
	private JTable tf3;
	private JTextField hj;
	public String m;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowTech frame = new ShowTech();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowTech() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Teacher Record");
		lblNewLabel.setBounds(612, 10, 148, 24);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel);
		
		JLabel lp = new JLabel("");
		lp.setBounds(851, 17, 217, 185);
		contentPane.add(lp);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(82, 88, 757, 166);
		contentPane.add(scrollPane);
		
		tf3 = new JTable();
		scrollPane.setViewportView(tf3);
		
		JButton btnNewButton = new JButton("Show");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 m=hj.getText();
					int k=Integer.parseInt(m);
					String d="SELECT Img FROM techreg WHERE Roll="+k;
					//String m=tff.getText();
					try {
						Conn cc=new Conn();
						ResultSet r=cc.s.executeQuery(d);
						if(r.next())
						{
							byte[]b=r.getBytes("img");
						
						lp.setIcon(new ImageIcon(b));
						}
					}
					catch(Exception kl){
						System.out.println(kl);
					}
					try {
						Conn cc=new Conn();
						
						//String q="SELECT Subject,Practical from umarks";
						//String ok="Select Name from studentreg";
						String q="SELECT ID,Name,Age,Gender,Subject from techreg WHERE Roll="+k;
						ResultSet rs = cc.s.executeQuery(q);
						
						//cc.r=cc.s.executeQuery(q);
						cc.rm=rs.getMetaData();
						DefaultTableModel model=(DefaultTableModel) tf3.getModel();
						int cols=cc.rm.getColumnCount();
						String[] colName=new String[cols];
						String  Id,nam,ag,g,sub;
						String rol,p,t,caa;
						for(int i=0;i<cols;i++)
							colName[i]=cc.rm.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						while(rs.next()) {
							Id=rs.getString("ID");
							nam=rs.getString("Name");
							ag=rs.getString("Age");
							g=rs.getString("Gender");
							sub=rs.getString("Subject");
							
							//String[]row= {rol,nam,ag,su,p,t,caa};
							String[]row= {Id,nam,ag,g,sub};
							model.addRow(row);
						}
						
					}
					catch(Exception e4)
					{
						System.out.println("The Error is :"+e4);
					}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(422, 54, 89, 23);
		contentPane.add(btnNewButton);
		
		hj = new JTextField();
		hj.setBounds(337, 54, 86, 23);
		contentPane.add(hj);
		hj.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("ID");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(307, 54, 29, 20);
		contentPane.add(lblNewLabel_2);
	}
}
