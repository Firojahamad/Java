package management;

import java.sql.*;  

public class Conn{
    Connection c;
    Statement s;
    ResultSet r;
    ResultSetMetaData rm;
    public Conn(){  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");    
            s =c.createStatement();  
            
            
           
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }  
}  
