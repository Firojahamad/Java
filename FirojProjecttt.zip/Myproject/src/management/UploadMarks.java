package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UploadMarks extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JTextField j1;
	private JTextField wp1;
	private JTextField cp3;
	private JTextField ep4;
	private JTextField dp5;
	private JTextField jt1;
	private JTextField wt2;
	private JTextField ct3;
	private JTextField et4;
	private JTextField dt5;
	private JTextField jca1;
	private JTextField wtca2;
	private JTextField cc3;
	private JTextField ec4;
	private JTextField dc5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UploadMarks frame = new UploadMarks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UploadMarks() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1795, 1650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Upload Marks");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(605, 10, 151, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Roll.no");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(510, 61, 76, 14);
		contentPane.add(lblNewLabel_1);
		
		t1 = new JTextField();
		t1.setBounds(605, 60, 138, 20);
		contentPane.add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Subject");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(440, 114, 97, 22);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Practical");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(581, 114, 76, 22);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Theory");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_4.setBounds(730, 110, 76, 30);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("CA");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_5.setBounds(861, 118, 46, 14);
		contentPane.add(lblNewLabel_5);
		
		j1 = new JTextField();
		j1.setColumns(10);
		j1.setBounds(581, 147, 86, 20);
		contentPane.add(j1);
		
		wp1 = new JTextField();
		wp1.setColumns(10);
		wp1.setBounds(581, 169, 86, 20);
		contentPane.add(wp1);
		
		cp3 = new JTextField();
		cp3.setColumns(10);
		cp3.setBounds(581, 192, 86, 20);
		contentPane.add(cp3);
		
		ep4 = new JTextField();
		ep4.setColumns(10);
		ep4.setBounds(581, 216, 86, 20);
		contentPane.add(ep4);
		
		dp5 = new JTextField();
		dp5.setColumns(10);
		dp5.setBounds(581, 238, 86, 20);
		contentPane.add(dp5);
		
		jt1 = new JTextField();
		jt1.setColumns(10);
		jt1.setBounds(720, 147, 86, 20);
		contentPane.add(jt1);
		
		wt2 = new JTextField();
		wt2.setColumns(10);
		wt2.setBounds(720, 169, 86, 20);
		contentPane.add(wt2);
		
		ct3 = new JTextField();
		ct3.setColumns(10);
		ct3.setBounds(720, 192, 86, 20);
		contentPane.add(ct3);
		
		et4 = new JTextField();
		et4.setColumns(10);
		et4.setBounds(720, 216, 86, 20);
		contentPane.add(et4);
		
		dt5 = new JTextField();
		dt5.setColumns(10);
		dt5.setBounds(720, 238, 86, 20);
		contentPane.add(dt5);
		
		jca1 = new JTextField();
		jca1.setColumns(10);
		jca1.setBounds(841, 147, 86, 20);
		contentPane.add(jca1);
		
		wtca2 = new JTextField();
		wtca2.setColumns(10);
		wtca2.setBounds(841, 169, 86, 20);
		contentPane.add(wtca2);
		
		cc3 = new JTextField();
		cc3.setColumns(10);
		cc3.setBounds(841, 192, 86, 20);
		contentPane.add(cc3);
		
		ec4 = new JTextField();
		ec4.setColumns(10);
		ec4.setBounds(841, 216, 86, 20);
		contentPane.add(ec4);
		
		dc5 = new JTextField();
		dc5.setColumns(10);
		dc5.setBounds(841, 238, 86, 20);
		contentPane.add(dc5);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String roll=t1.getText();
				String sub1="Java";
				String sub2="Web Tech";
				String sub3="CPP";
				String sub4="Discreate Mathmetics";
				String sub5="Ethics";
				String javap=j1.getText();
				String javat=jt1.getText();
				String javac=jca1.getText();
				String webp=wp1.getText();
				String webtt=wt2.getText();
				String wtca=wtca2.getText();
				String cppp=cp3.getText();
				String cppt=ct3.getText();
				String cppc=cc3.getText();
				String ep=ep4.getText();
				String et=et4.getText();
				String ec=ec4.getText();
				String dp=dp5.getText();
				String dt=dt5.getText();
				String dc=dc5.getText();
				if(e.getSource()==btnNewButton)
				{
					try {
						Conn cc=new Conn();
						String q="insert into umarks values('"+roll+"','"+sub1+"','"+javap+"','"+javat+"','"+javac+"')";
						String w="insert into umarks values('"+roll+"','"+sub2+"','"+webp+"','"+webtt+"','"+wtca+"')";
						String z="insert into umarks values('"+roll+"','"+sub3+"','"+cppp+"','"+cppt+"','"+cppc+"')";
						String x="insert into umarks values('"+roll+"','"+sub4+"','"+ep+"','"+et+"','"+ec+"')";
						String h="insert into umarks values('"+roll+"','"+sub5+"','"+dp+"','"+dt+"','"+dc+"')";
						cc.s.executeUpdate(q);
						cc.s.executeUpdate(w);
						cc.s.executeUpdate(z);
						cc.s.executeUpdate(x);
						cc.s.executeUpdate(h);
						JOptionPane.showMessageDialog(null,"Data inserted");
						ExamTimeTable ob=new ExamTimeTable();
						ob.setVisible(false);
					}
					catch(Exception e4)
					{
						System.out.println("The Error is :"+e4);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(640, 280, 103, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_2_1 = new JLabel("JAVA");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_1.setBounds(427, 147, 97, 20);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("WEB TECHNOLOGY");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_2.setBounds(373, 172, 151, 22);
		contentPane.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("CPP");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_3.setBounds(427, 195, 97, 22);
		contentPane.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel("ETHICS");
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_4.setBounds(427, 216, 97, 22);
		contentPane.add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_2_5 = new JLabel("DISCRETE MATHETICS");
		lblNewLabel_2_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_5.setBounds(356, 238, 168, 22);
		contentPane.add(lblNewLabel_2_5);
	}
}
